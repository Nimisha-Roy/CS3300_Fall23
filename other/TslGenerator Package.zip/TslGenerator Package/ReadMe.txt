To download:
https://github.com/alexorso/tslgenerator/tree/master/Binaries

run the code: ./TSLgenerator-win8.exe 

help: ./TSLgenerator-win8.exe --manpage

./TSLgenerator-win8.exe -c 1.spec.plain
./TSLgenerator-win8.exe -c 2.spec.const
